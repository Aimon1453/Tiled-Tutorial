<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Overhead Objects" tilewidth="16" tileheight="48" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="16" height="48" source="pillar.png"/>
  <objectgroup draworder="index">
   <object id="2" x="0" y="32" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <image width="16" height="32" source="pilllar-broken.png"/>
  <objectgroup draworder="index">
   <object id="1" x="0" y="16" width="16" height="16"/>
  </objectgroup>
 </tile>
</tileset>
