﻿namespace SuperTiled2Unity.Ase.Editor
{
    public enum ColorDepth : ushort
    {
        Indexed8 = 8,
        Grayscale16 = 16,
        RGBA32 = 32,
    }
}
