﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperTiled2Unity.Ase.Editor
{
    public enum ColorProfileType : ushort
    {
        NoColorProfile = 0,
        sRGB = 1,
        EmbeddedICC = 2,
    }
}
