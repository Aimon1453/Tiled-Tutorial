﻿namespace SuperTiled2Unity.Ase.Editor
{
    public enum CelType : ushort
    {
        Raw = 0,
        Linked = 1,
        CompressedImage = 2,
        CompressedTilemap = 3,
    }
}
