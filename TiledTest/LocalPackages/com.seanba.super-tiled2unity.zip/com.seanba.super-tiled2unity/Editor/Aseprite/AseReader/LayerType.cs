﻿namespace SuperTiled2Unity.Ase.Editor
{
    public enum LayerType : ushort
    {
        Normal = 0,
        Group = 1,
        Tilemap = 2,
    }
}
