﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperTiled2Unity.Ase.Editor
{
    public enum SliceFlags : uint
    {
        Is9PatchSlice = 1,
        HasPivotInformation = 2,
    }
}
