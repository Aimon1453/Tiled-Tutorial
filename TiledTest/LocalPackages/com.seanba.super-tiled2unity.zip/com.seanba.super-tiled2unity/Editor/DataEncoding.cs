﻿namespace SuperTiled2Unity.Editor
{
    public enum DataEncoding
    {
        Xml,
        Base64,
        Csv,
    }
}
