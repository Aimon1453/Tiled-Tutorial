﻿namespace SuperTiled2Unity
{
    public enum StaggerIndex
    {
        Even,
        Odd,
    }
}
