﻿namespace SuperTiled2Unity
{
    public enum TileRenderSize
    {
        Tile,
        Grid,
    }
}
