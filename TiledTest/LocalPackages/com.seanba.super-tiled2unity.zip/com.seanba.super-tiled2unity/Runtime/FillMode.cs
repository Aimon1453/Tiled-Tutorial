﻿namespace SuperTiled2Unity
{
    public enum FillMode
    {
        Stretch,
        Preserve_Aspect_Fit,
    }
}
